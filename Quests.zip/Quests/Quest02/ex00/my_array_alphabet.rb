
# A function that creates and return an array of alphabets from A-Z
def my_array_alphabet()
    return ('a'..'z').to_a
end

# to display the array
puts my_array_alphabet()