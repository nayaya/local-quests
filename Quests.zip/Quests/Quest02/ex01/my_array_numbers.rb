# A function that creates an array of integers from 0 - 14
def my_array_numbers()
    return (0..14).to_a
end

# to display the result
print my_array_numbers()