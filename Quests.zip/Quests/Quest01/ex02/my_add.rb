
# A function that accepts two int params and retuirn their sum
def my_add(nbr1, nbr2)
  return nbr1 + nbr2
end

# Display of the Sum by callig the function
puts my_add(2, 3)