
# A function that returns the absolute value of the parameter supplied
def my_abs(nbr)
  nbr < 0 ? nbr * -1 : nbr
end

# To display the results
puts my_abs(-3)