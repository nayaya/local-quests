
# A function that returns the string supplied with the first letter capitalized. 
def my_capitalize(str)
    str.capitalize()
end
  
  # To display the result
  puts my_capitalize("Hello DUNIYA")