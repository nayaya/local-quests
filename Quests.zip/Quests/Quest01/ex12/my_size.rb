
# A function that returns the length of the string supplied. 
def my_size(str)
    str.size()
end
  
# To display the result
puts my_size("Hello DUNIYA")