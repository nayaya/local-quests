
# a function that returns the difference of two numbers
def my_sub(nbr1, nbr2)
  nbr1 - nbr2
end

# To display the result
puts my_sub(2, 3)