
# A function that returns the product of two numbers
def my_mult(nbr1, nbr2)
  return nbr1 * nbr2
end

# To display the result
puts my_mult(2, 3)