
# A function that accepts three strings and return a string composed of the three params
def my_string_formatting(firstname, lastname, age)
  "#{firstname} #{lastname} #{age}"
end

# To dsiplay the result
puts my_string_formatting("Ibrahim", "Bashir", "27")
