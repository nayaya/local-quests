# This is The Function ProtoType
# def my_is_negative(num)
    
# This is The Function Definiton: A function that accepts an integer 
# parameter and returns 0 if its negative and 1 otherwise
def my_is_negative(n)
    return n < 0 ? 0 : 1
end

# The function called with a negative value (-3)
puts my_is_negative(-3)