
# A function that takes a string and a character, and returns the index
# of the first occurance of the character on the string supplied
def my_string_index(str, n)
  str.index(n)
end

# To display the result
puts my_string_index("Hello", 'e')