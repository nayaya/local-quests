
# A function that returns the lower case of the string supplied. 
def my_downcase(str)
    str.downcase()
end
  
  # To display the result
  puts my_downcase("Hello DUNIYA")