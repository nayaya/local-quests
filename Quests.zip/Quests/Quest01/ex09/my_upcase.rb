
# A function that returns the upper case of the string supplied. 
def my_upcase(str)
  str.upcase()
end

# To display the result
puts my_upcase("Hello DUNIYA")