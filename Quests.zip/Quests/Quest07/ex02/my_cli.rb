require 'readline'

def my_cli
    begin
        line = Readline.readline('> ', true)
        while line != "exit"
            p line.split
            line = Readline.readline('> ', true)
        end
        puts "Goodbye!"
    rescue Interrupt => e
        puts e
        exit
    end
end

my_cli