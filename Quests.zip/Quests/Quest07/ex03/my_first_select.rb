require 'csv'

class  MyFirstSelect
   
    def initialize my_csv
        @my_csv_file = my_csv
        @columns = []
        @data = []    
        load
    end

    def load
       info = CSV.read(@my_csv_file)
       info.each_with_index do |datum, index|
            unless index == 0
                datum.delete_at(0)
                @data << datum
            else
                @columns = datum
            end
        end
    end

    def where(column_name, value)
        column_position = @columns.find_index(column_name)
        info = []
        results = []
        @data.each do |item|
            if item[column_position] === value
                info << item
            end
        end
        info.each do |row|
            record = Hash.new
            row.each_with_index do |column, i|
                record[@columns[i]] = column
            end
            results << record
        end
        p results
    end
end

mySelect = MyFirstSelect.new('seasons_stats.csv')
mySelect.where('Player', 'Max Zaslofsky')