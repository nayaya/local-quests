# 

# Importing The CSV Library for parsing .csv files
require 'csv'
require 'benchmark'
require "get_process_mem"

# Class Definition
class  MyFirstSelectWithJoin
   
    # This is the initialize function that is implicitly called
    # at the point of the class Object Creation; It require an initial
    #  .csv file name as parameter
    def initialize my_csv
        # Instance variable to save the filename
        @my_csv_file = my_csv
        # Instance variable to save initial file columns
        @columns = []
        # Instance Variable to save join file columns
        @columns1 = []
        # Instance variable to load initial file data
        @data = []
        # Instance variable to load join file data
        @data1 = []  
        # Instance variable to store combined data after join
        @database = [] 
        # A call to load funcion to load the CSV files
        load
    end

    def join col_db_a, other_csv, col_db_b

        CSV.foreach(other_csv, headers: true).each_with_index do |datum, index|
            @data1 << datum.to_h
        end
       
        @data.each_with_index do |item, i|
            @data1.each do |row| 
                # p item[col_db_a]
                if item[col_db_a] === row[col_db_b]
                    @database << item.merge(row)
                end
            end
        end
        p @database.size
    end

    def load
        CSV.foreach(@my_csv_file, headers: true).each_with_index do |datum, index|
            index == 0 ? @data.to_h : @data << datum.to_h
        end
    end

    def get_matches column_name, value
        info = []
        @database.each do |item|
            item[column_name] === value && info << item
        end
        return info
    end

    def structured array 
        results = []
        array.each do |row|
            record = Hash.new
            row.each_with_index do |column, i|
                record[@columns[i]] = column
            end
            results << record
        end
        return results
    end

    def where(column_name, value)
        p get_matches(column_name, value)
        # p structured(matches)
    end
end

def print_memory_usage
    before = GetProcessMem.new.mb
    yield
    after = GetProcessMem.new.mb
    puts "MEMORY USAGE(MB): #{ after.round/before.round } MB"
end
  
def print_time_spent
    time = Benchmark.realtime do
      yield
    end
    puts "Time: #{time.round(2)}"
end

print_memory_usage do 
    print_time_spent do   
        mySelect = MyFirstSelectWithJoin.new('nba_players.csv')
        mySelect.join('Player', 'nba_player_data.csv', 'name')
        mySelect.where("Player", "Frankie Brian")
    end
end
