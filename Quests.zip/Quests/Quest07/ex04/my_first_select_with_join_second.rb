# Importing Libraries Library for parsing .csv files
require 'csv'
# require_relative './helpers'
require 'benchmark'
require "get_process_mem"

# Class Definition
class  MyFirstSelectWithJoin
   
    # This is the initialize function that is implicitly called
    # at the point of the class Object Creation; It require an initial
    #  .csv file name as parameter
    def initialize my_csv
        # Instance variable to save the filename
        @my_csv_file = my_csv
        # Instance variable to save initial file columns
        @columns = []
        # Instance Variable to save joining file columns
        @columns1 = []
        # Instance variable to save initial file data
        @data = []
        # Instance Variable to save joining file data
        @data1 = []
        # Instance variable to store combined data after join
        @database = [] 
        # A call to load funcion to load the initial CSV files columns
        load()
    end

    def join(col_db_a, other_csv, col_db_b)

        CSV.foreach(other_csv).with_index do |datum, index|
            index == 0 && @columns1 = datum
            @data1 << datum
        end

        @columns = @columns + @columns1
        column_position = @columns.find_index(col_db_a)
        column_position1 = @columns1.find_index(col_db_b)

        CSV.foreach(@my_csv_file).with_index do |item, index|
            next if index == 0
            CSV.foreach(other_csv).with_index do |row, i| 
                next if i == 0
                if col_db_a === col_db_b && item[column_position + 1] === row[column_position1 + 1]
                    @database << item + row.drop(1)
                end
            end
        end
        p @database.size()
    end

    def load()
        CSV.foreach(@my_csv_file).with_index do |datum, index|
            index == 0 && @columns = datum
            @data << datum
        end
    end

    def where(column_name, value)
        matches = get_matches(column_name, value)
        p structured(matches)
    end

    def get_index(column_record = @columns, col_name)
        return column_record.find_index(col_name)
    end

    def get_matches(column_name, value)
        position = get_index(@columns, column_name)
        info = []
        @database.each do |item|
            if item[position + 1] === value
                info << item.drop(1)
            end
        end
        return info
    end

    def structured(matches) 
        results = []
        matches.each do |row|
            record = Hash.new
            row.each_with_index do |column, i|
                record[@columns[i]] = column
            end
            results << record
        end
        return results
    end
end

def print_memory_usage
    before = GetProcessMem.new.mb
    yield
    after = GetProcessMem.new.mb
    puts "MEMORY USAGE(MB): #{ after.round/before.round } MB"
end
  
def print_time_spent
    time = Benchmark.realtime do
      yield
    end
    puts "Time: #{time.round(2)}"
end

print_memory_usage do 
    print_time_spent do   
        mySelect = MyFirstSelectWithJoin.new('seasons_stats.csv')
        mySelect.join('Player', 'nba_players.csv', 'Player')
        mySelect.where("Player", "Charlie Black")
    end
end
