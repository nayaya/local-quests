require 'sinatra'
# require 'sinatra/cookies'
require 'json'

set :bind, '0.0.0.0'
set :port, 8080

get '/' do
    action, name, value = params[:action], params[:name], params[:value]
    case action
    when 'set'
        response.set_cookie(name, value) && ""
        # "Cookie Set: [#{name}, #{value}] succesfully"
    when 'get'
        request.cookies[name]
        # "Cookie Found: #{}"
    when 'del'
        response.delete_cookie(name) && ""
        # "Cookie is deleted successfully"
    else
        request.cookies
    end
end