require 'sinatra'
# require 'json'

enable :sessions 
set :bind, '0.0.0.0'
set :port, 8081

get '/welcome' do
    "Hello, #{session[:name]}!"
  end

get '/' do

    action, name, value = params[:action], params[:name], params[:value]

    case action
    when 'set'
        session[:name] = value
        redirect '/welcome'
    when 'get'
        session[:name]
    when 'del'
        session.delete(:name)
    else
        session
    end

end