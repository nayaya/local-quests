require 'sinatra'
set :bind, '0.0.0.0'
set :port, 8082

get '/' do
   "Everybody can see this page"
end

get '/protected/:username/:password' do
    if params[:username] == 'Admin' && params[:password] == "Password"
        return "Welcome, authenticated client" 
    else
         status 401 
         return "Not authorized"
    end
end