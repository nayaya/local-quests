require 'PP'
require 'json'
class User 

    @user = Hash.new

    def initialize database = 'db.raw'
        @database = database
    end

    def create(user_info)
        data = File.open(@database).to_a
        if !data.empty? 
            curr_id = eval(data.last)[:id].to_i
        else
            curr_id = 0
        end
        curr_id += 1
        if user_info.is_a?(Hash) 
            File.open(@database, 'a+') do |file|
                new_user = {:id => curr_id}.merge(user_info)
                file.puts new_user.to_s
                file.close
            end
            return curr_id
        else
            return nil
        end 
    end

    def get(id)
        file = File.open(@database)
        data = file.readlines.map(&:chomp)
        file.close
        if !data.empty?
             record = data.select { |row| eval(row)[:id].to_i == id }
             if record.size != 0
                @user = eval(record[0])
             end
        else
            return "Database Empty"
        end
        !@user.empty? ? @user : "Record Not Found"
    end

    def all()
        file = File.open(@database)
        data = file.readlines.map(&:chomp)
        file.close
        result = []
        if !data.empty?
            data.each do |record|
                user = eval(record)
                result << user
            end
        else
            return "Database Empty"
        end
        return result
    end

    def update(id, attr, val)
        file = File.open(@database, 'r+')
        data = file.readlines.map(&:chomp)
        if !data.empty?
            record = data.find { |row| eval(row)[:id].to_i == id}
            user = record != nil ? eval(record) : []
            if !user.empty?
                i = data.index(record.to_s)
                case attr
                when 'firstname'
                    user[:firstname] = val
                when 'lastname'
                    user[:lastname] = val
                when 'age'
                    user[:age] = val
                when 'email'
                    user[:email] = val
                when 'password'
                    user[:password] = val
                else
                    return "Invalid Field"
                end
                data[i] = user.to_s
                File.open(@database, 'w') do |file|
                    data.each_with_index do |record, i|
                        file.write record + "\n"
                    end
                end     
               get id
            else
                return "Record Not Found"
            end
        else
            return "Database Empty"
       end
    end

    def destroy(id)
        data = File.readlines(@database)
        if !data.empty?
            record = data.find { |row| eval(row)[:id].to_i == id}
            index = data.index(record)
            return index != nil && index >= 0 && data.delete_at(index) ? "Deleted Successfully"  : "Record not found" 
            File.open(@database, 'w') do |file|
                file.write data
            end
        else
            return "Database Empty"
        end
    end
end

test_user = {
    :firstname => "James",
    :lastname => "McNaugh",
    :age => "38",
    :email => "james@example.com",
    :password => "password"
}
user = User.new()
puts user.create(test_user);
# puts user.get(6)
# pp user.all()
# pp user.update(4, 'age', 27)
# puts user.get(4)
# pp user.destroy(7)