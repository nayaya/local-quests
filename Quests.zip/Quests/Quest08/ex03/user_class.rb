require 'PP'
require 'json'
class User 

    @user = Hash.new

    def initialize database = 'db.raw'
        @database = File.open(database, 'r+')
        @file = database
    end

    def close 
        @database.close
    end

    def create(user_info)
        data = @database.to_a
        if !data.empty? 
            curr_id = eval(data.last)[:id].to_i
        else
            curr_id = 0
        end
        curr_id += 1
        if user_info.is_a?(Hash)
            new_user = {:id => curr_id}.merge(user_info)
            @database.write(new_user.to_s + "\n")
            close()
            return curr_id
        else
            return nil
        end 
    end

    def get(id)
        data = @database.readlines.map(&:chomp)
        if !data.empty?
             record = data.select { |row| eval(row)[:id].to_i == id }
             if record.size != 0
                @user = eval(record.first)
             end
        else
            return "Database Empty"
        end
        !@user.empty? ? @user : "Record Not Found"
    end

    def all()
        data = @database.readlines.map(&:chomp)
        result = []
        if !data.empty?
            data.each do |record|
                user = eval(record)
                result << user
            end
        else
            return "Database Empty"
        end
        return result
    end

    def update(id, attr, val)
        data = @database.readlines.map(&:chomp)
        if !data.empty?
            record = data.find { |row| eval(row)[:id].to_i == id}
            user = record != nil ? eval(record) : []
            if !user.empty?
                i = data.index(record.to_s)
                case attr
                when 'firstname'
                    user[:firstname] = val
                when 'lastname'
                    user[:lastname] = val
                when 'age'
                    user[:age] = val
                when 'email'
                    user[:email] = val
                when 'password'
                    user[:password] = val
                else
                    return "Invalid Field"
                end
                data[i] = user.to_s
                @database.truncate(0)
                data.each_with_index do |record, i|
                    @database.write record + "\n"
                end
                get id
                close()
            else
                return "Record Not Found"
            end
        else
            return "Database Empty"
       end
    end

    def destroy(id)
        data = @database.readlines.map(&:chomp)
        if !data.empty?
            record = data.find { |row| eval(row)[:id].to_i == id}
            index = data.index(record)
            if index != nil && index >= 0 && data.delete_at(index) 
                data.each do |record|
                    @database.write record
                end
                close()
                return "Deleted Successfully"
            else
                return "Record not found"  
            end   
        else
            return "Database Empty"
        end
    end
end

test_user = {
    :firstname => "John",
    :lastname => "Doe",
    :age => "25",
    :email => "doe@example.com",
    :password => "password"
}
user = User.new()
puts user.create(test_user);
# puts user.get(4)
# pp user.all()
# pp user.update(4, 'age', '17')
# pp user.destroy(6)